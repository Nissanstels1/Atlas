"""Namespaced administrator-authored outbound graphs.

Protocol fields are validated by the installed sing-box, rather than a stale
allowlist. References cannot escape this graph into another section.
"""
import copy
import json
import re


def outbound_graph(value):
    if isinstance(value, dict):
        value = value.get('outbounds') if set(value) == {'outbounds'} else [value]
    if not isinstance(value, list) or len(value) > 64:
        raise ValueError('JSON outbound: объект или список до 64 объектов')
    try:
        encoded = json.dumps(value, allow_nan=False)
    except (ValueError, TypeError, RecursionError):
        raise ValueError('Некорректный JSON outbound') from None
    if len(encoded.encode()) > 128 * 1024:
        raise ValueError('JSON outbound ограничен 128 КиБ')
    graph = copy.deepcopy(value)
    tags = set()
    for index, item in enumerate(graph):
        if not isinstance(item, dict) or not isinstance(item.get('type'), str):
            raise ValueError('Каждый outbound требует поле type')
        if not re.fullmatch('[a-z][a-z0-9_-]{0,31}', item['type']):
            raise ValueError('Некорректный type outbound')
        item.setdefault('tag', 'entry' if index == 0 else 'node%d' % index)
        tag = item['tag']
        if not isinstance(tag, str) or not re.fullmatch('[A-Za-z0-9_.-]{1,64}', tag) or tag in tags:
            raise ValueError('Теги outbound должны быть уникальными: буквы, цифры, ._-')
        tags.add(tag)
    edges = {}
    for item in graph:
        refs = []
        for field in ('detour', 'default'):
            if field in item:
                if not isinstance(item[field], str):
                    raise ValueError('Ссылка outbound должна быть строкой')
                refs.append(item[field])
        if 'outbounds' in item:
            if not isinstance(item['outbounds'], list) or any(not isinstance(x, str) for x in item['outbounds']):
                raise ValueError('outbounds должен быть списком тегов')
            refs.extend(item['outbounds'])
        if any(tag not in tags for tag in refs):
            raise ValueError('Ссылка на отсутствующий outbound в этой секции')
        edges[item['tag']] = refs
    visited, visiting = set(), set()
    def visit(tag):
        if tag in visiting:
            raise ValueError('Цикл ссылок между outbound')
        if tag in visited:
            return
        visiting.add(tag)
        for child in edges[tag]:
            visit(child)
        visiting.remove(tag)
        visited.add(tag)
    for tag in edges:
        visit(tag)
    return graph


def namespace_graph(graph, prefix):
    graph = outbound_graph(graph)
    names = {item['tag']: prefix + '_' + item['tag'] for item in graph}
    for item in graph:
        item['tag'] = names[item['tag']]
        for field in ('detour', 'default'):
            if field in item:
                item[field] = names[item[field]]
        if 'outbounds' in item:
            item['outbounds'] = [names[tag] for tag in item['outbounds']]
    return graph, graph[0]['tag'] if graph else None
